import org.apache.log4j.LogManager;
import twitter4j.*;

import java.util.Map;
import java.util.UUID;

public class TweetRetriever {
    public static final String SPLITERATOR = "MySpl!ter@tor";
    private static final int MAX_QUERIES = 100000000;    //  Change Max Queries for many terms
    public static org.apache.log4j.Logger log = LogManager.getLogger(TweetRetriever.class);

    public static void fetchSearchTerms(String[] SEARCH_TERMS) throws Exception {
        for (String searchTerm : SEARCH_TERMS) {
            fetch(searchTerm);
        }
    }

    private static void fetch(String searchTerm) throws Exception {
        long maxID = -1L;
        Twitter twitter = TweetUtils.createTwitter();

        String filename = "Outputs/" + searchTerm + UUID.randomUUID().toString();
        String headers = "ID    CREATED_AT    TAG    TWEET    NEG    NEU    POS    COMPOUND    SENTIMENT\n";
        TweetUtils.createFileWithHeaders(filename,headers);

        RateLimitStatus searchTweetsRateLimit = getRateLimitStatus(twitter);
        fetchSearchTerm(searchTerm, maxID, twitter, searchTweetsRateLimit, filename);
    }

    private static void fetchSearchTerm(String searchTerm, long maxID, Twitter twitter, RateLimitStatus searchTweetsRateLimit, String filename) throws Exception {
        log.info(String.format("Querying For HashTag: %s",searchTerm));
        for (int queryNumber = 0; queryNumber < MAX_QUERIES; queryNumber++) {
            log.info(String.format("Starting loop %s", queryNumber));
            waitForRateLimitIfNecessary(searchTweetsRateLimit);
            Query query = createQuery(searchTerm, maxID);
            QueryResult queryResult = twitter.search(query);
            if (queryResult.getTweets().size() == 0) {
                break;
            }

            maxID = processTweetsInQuery(searchTerm, maxID, queryResult, filename);
            searchTweetsRateLimit = queryResult.getRateLimitStatus();
        }
    }

    private static long processTweetsInQuery(String searchTerm, long maxID, QueryResult queryResult, String filename) throws Exception {
        for (Status tweetStatus : queryResult.getTweets()) {
            if (maxID == -1 || tweetStatus.getId() < maxID) {
                maxID = tweetStatus.getId();
            }
            String createdAt = TweetUtils.DATE_FORMAT.format(tweetStatus.getCreatedAt());
            Tweet tweet = new Tweet(tweetStatus.getId(),createdAt,searchTerm,tweetStatus.getText());
            TweetUtils.WriteTweetToFile(tweet, filename);
        }
        return maxID;
    }


    private static Query createQuery(String searchTerm, long maxID) {
        Query query = new Query(searchTerm);
        query.setCount(100);
        query.resultType(Query.ResultType.recent);
        query.setLang("en");

        if (maxID != -1) {
            query.setMaxId(maxID - 1);
        }
        return query;
    }

    private static void waitForRateLimitIfNecessary(RateLimitStatus searchTweetsRateLimit) throws InterruptedException {
        if (searchTweetsRateLimit.getRemaining() == 0) {
            log.info(String.format("!!! Sleeping for %s seconds due to rate limits\n", searchTweetsRateLimit.getSecondsUntilReset()));
            Thread.sleep((searchTweetsRateLimit.getSecondsUntilReset() + 50) * 1000L);
        }
    }

    private static RateLimitStatus getRateLimitStatus(Twitter twitter) throws TwitterException {
        Map<String, RateLimitStatus> rateLimitStatus = twitter.getRateLimitStatus("search");
        RateLimitStatus searchTweetsRateLimit = rateLimitStatus.get("/search/tweets");
        log.info(String.format("You have %s calls remaining out of %s, Limit resets in %s seconds\n",
                searchTweetsRateLimit.getRemaining(),
                searchTweetsRateLimit.getLimit(),
                searchTweetsRateLimit.getSecondsUntilReset()));
        return searchTweetsRateLimit;
    }
}
