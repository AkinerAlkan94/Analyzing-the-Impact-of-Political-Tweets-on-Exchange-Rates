public class OrganisedTweetResult {
    String createdAt;
    String tagName;
    String totalTweetCount;
    String totalPositiveTweetCount;
    String totalNeuTweetCount;
    String totalNegTweetCount;
    String totalCompoundAverage;
    String positiveOverTotal;
    String neutralOverTotal;
    String negativeOverTotal;

    public OrganisedTweetResult(String createdAt,
                                String tagName,
                                String totalTweetCount,
                                String totalPositiveTweetCount,
                                String totalNeuTweetCount,
                                String totalNegTweetCount,
                                String totalCompoundAverage,
                                String positiveOverTotal,
                                String neutralOverTotal,
                                String negativeOverTotal) {
        this.createdAt = createdAt;
        this.tagName = tagName;
        this.totalTweetCount = totalTweetCount;
        this.totalPositiveTweetCount = totalPositiveTweetCount;
        this.totalNeuTweetCount = totalNeuTweetCount;
        this.totalNegTweetCount = totalNegTweetCount;
        this.totalCompoundAverage = totalCompoundAverage;
        this.positiveOverTotal = positiveOverTotal;
        this.neutralOverTotal = neutralOverTotal;
        this.negativeOverTotal = negativeOverTotal;
    }
}
