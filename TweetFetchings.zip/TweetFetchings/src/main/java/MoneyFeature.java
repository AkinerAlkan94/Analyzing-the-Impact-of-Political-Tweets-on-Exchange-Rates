public class MoneyFeature {
    String createdAt;
    String featureName;
    String featureValue;

    public MoneyFeature(String createdAt, String featureName, String featureValue) {
        this.createdAt = createdAt;
        this.featureName = featureName;
        this.featureValue = featureValue;
    }
}
