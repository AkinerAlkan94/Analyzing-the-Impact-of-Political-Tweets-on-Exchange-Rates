import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Shifter {


    private static ArrayList<MachineLearningInputRow> readMachineLearningFile(String organisedForMachineLearningInputFile) throws IOException {
        ArrayList<MachineLearningInputRow> machineLearningInputRows = new ArrayList<>();
        List<String> lines = Files.readAllLines(Paths.get(organisedForMachineLearningInputFile));

        for (String line : lines) {
            String[] components = line.split(" ");
            MachineLearningInputRow row = new MachineLearningInputRow(components[0]);
            row.totalTweetCountBreaking = components[1];
            row.totalPosTweetsBreaking = components[2];
            row.totalNeuTweetsBreaking = components[3];
            row.totalNegTweetsBreaking = components[4];
            row.totalCompoundAverageBreaking = components[5];
            row.posOverTotalBreaking = components[6];
            row.neuOverTotalBreaking = components[7];
            row.negOverTotalBreaking = components[8];
            row.totalTweetCountBreakingnews = components[9];
            row.totalPosTweetsBreakingnews = components[10];
            row.totalNeuTweetsBreakingnews = components[11];
            row.totalNegTweetsBreakingnews = components[12];
            row.totalCompoundAverageBreakingnews = components[13];
            row.posOverTotalBreakingnews = components[14];
            row.neuOverTotalBreakingnews = components[15];
            row.negOverTotalBreakingnews = components[16];
            row.totalTweetCountCurrency = components[17];
            row.totalPosTweetsCurrency = components[18];
            row.totalNeuTweetsCurrency = components[19];
            row.totalNegTweetsCurrency = components[20];
            row.totalCompoundAverageCurrency = components[21];
            row.posOverTotalCurrency = components[22];
            row.neuOverTotalCurrency = components[23];
            row.negOverTotalCurrency = components[24];
            row.totalTweetCountDay = components[25];
            row.totalPosTweetsDay = components[26];
            row.totalNeuTweetsDay = components[27];
            row.totalNegTweetsDay = components[28];
            row.totalCompoundAverageDay = components[29];
            row.posOverTotalDay = components[30];
            row.neuOverTotalDay = components[31];
            row.negOverTotalDay = components[32];
            row.totalTweetCountDolar = components[33];
            row.totalPosTweetsDolar = components[34];
            row.totalNeuTweetsDolar = components[35];
            row.totalNegTweetsDolar = components[36];
            row.totalCompoundAverageDolar = components[37];
            row.posOverTotalDolar = components[38];
            row.neuOverTotalDolar = components[39];
            row.negOverTotalDolar = components[40];
            row.totalTweetCountDollar = components[41];
            row.totalPosTweetsDollar = components[42];
            row.totalNeuTweetsDollar = components[43];
            row.totalNegTweetsDollar = components[44];
            row.totalCompoundAverageDollar = components[45];
            row.posOverTotalDollar = components[46];
            row.neuOverTotalDollar = components[47];
            row.negOverTotalDollar = components[48];
            row.totalTweetCountDonaldtrump = components[49];
            row.totalPosTweetsDonaldtrump = components[50];
            row.totalNeuTweetsDonaldtrump = components[51];
            row.totalNegTweetsDonaldtrump = components[52];
            row.totalCompoundAverageDonaldtrump = components[53];
            row.posOverTotalDonaldtrump = components[54];
            row.neuOverTotalDonaldtrump = components[55];
            row.negOverTotalDonaldtrump = components[56];
            row.totalTweetCountEconomy = components[57];
            row.totalPosTweetsEconomy = components[58];
            row.totalNeuTweetsEconomy = components[59];
            row.totalNegTweetsEconomy = components[60];
            row.totalCompoundAverageEconomy = components[61];
            row.posOverTotalEconomy = components[62];
            row.neuOverTotalEconomy = components[63];
            row.negOverTotalEconomy = components[64];
            row.totalTweetCountEuro = components[65];
            row.totalPosTweetsEuro = components[66];
            row.totalNeuTweetsEuro = components[67];
            row.totalNegTweetsEuro = components[68];
            row.totalCompoundAverageEuro = components[69];
            row.posOverTotalEuro = components[70];
            row.neuOverTotalEuro = components[71];
            row.negOverTotalEuro = components[72];
            row.totalTweetCountExchange = components[73];
            row.totalPosTweetsExchange = components[74];
            row.totalNeuTweetsExchange = components[75];
            row.totalNegTweetsExchange = components[76];
            row.totalCompoundAverageExchange = components[77];
            row.posOverTotalExchange = components[78];
            row.neuOverTotalExchange = components[79];
            row.negOverTotalExchange = components[80];
            row.totalTweetCountForex = components[81];
            row.totalPosTweetsForex = components[82];
            row.totalNeuTweetsForex = components[83];
            row.totalNegTweetsForex = components[84];
            row.totalCompoundAverageForex = components[85];
            row.posOverTotalForex = components[86];
            row.neuOverTotalForex = components[87];
            row.negOverTotalForex = components[88];
            row.totalTweetCountInvesting = components[89];
            row.totalPosTweetsInvesting = components[90];
            row.totalNeuTweetsInvesting = components[91];
            row.totalNegTweetsInvesting = components[92];
            row.totalCompoundAverageInvesting = components[93];
            row.posOverTotalInvesting = components[94];
            row.neuOverTotalInvesting = components[95];
            row.negOverTotalInvesting = components[96];
            row.totalTweetCountMarket = components[97];
            row.totalPosTweetsMarket = components[98];
            row.totalNeuTweetsMarket = components[99];
            row.totalNegTweetsMarket = components[100];
            row.totalCompoundAverageMarket = components[101];
            row.posOverTotalMarket = components[102];
            row.neuOverTotalMarket = components[103];
            row.negOverTotalMarket = components[104];
            row.totalTweetCountMoney = components[105];
            row.totalPosTweetsMoney = components[106];
            row.totalNeuTweetsMoney = components[107];
            row.totalNegTweetsMoney = components[108];
            row.totalCompoundAverageMoney = components[109];
            row.posOverTotalMoney = components[110];
            row.neuOverTotalMoney = components[111];
            row.negOverTotalMoney = components[112];
            row.totalTweetCountObama = components[113];
            row.totalPosTweetsObama = components[114];
            row.totalNeuTweetsObama = components[115];
            row.totalNegTweetsObama = components[116];
            row.totalCompoundAverageObama = components[117];
            row.posOverTotalObama = components[118];
            row.neuOverTotalObama = components[119];
            row.negOverTotalObama = components[120];
            row.totalTweetCountStock = components[121];
            row.totalPosTweetsStock = components[122];
            row.totalNeuTweetsStock = components[123];
            row.totalNegTweetsStock = components[124];
            row.totalCompoundAverageStock = components[125];
            row.posOverTotalStock = components[126];
            row.neuOverTotalStock = components[127];
            row.negOverTotalStock = components[128];
            row.totalTweetCountStockmarket = components[129];
            row.totalPosTweetsStockmarket = components[130];
            row.totalNeuTweetsStockmarket = components[131];
            row.totalNegTweetsStockmarket = components[132];
            row.totalCompoundAverageStockmarket = components[133];
            row.posOverTotalStockmarket = components[134];
            row.neuOverTotalStockmarket = components[135];
            row.negOverTotalStockmarket = components[136];
            row.totalTweetCountStocks = components[137];
            row.totalPosTweetsStocks = components[138];
            row.totalNeuTweetsStocks = components[139];
            row.totalNegTweetsStocks = components[140];
            row.totalCompoundAverageStocks = components[141];
            row.posOverTotalStocks = components[142];
            row.neuOverTotalStocks = components[143];
            row.negOverTotalStocks = components[144];
            row.totalTweetCountToday = components[145];
            row.totalPosTweetsToday = components[146];
            row.totalNeuTweetsToday = components[147];
            row.totalNegTweetsToday = components[148];
            row.totalCompoundAverageToday = components[149];
            row.posOverTotalToday = components[150];
            row.neuOverTotalToday = components[151];
            row.negOverTotalToday = components[152];
            row.totalTweetCountTrading = components[153];
            row.totalPosTweetsTrading = components[154];
            row.totalNeuTweetsTrading = components[155];
            row.totalNegTweetsTrading = components[156];
            row.totalCompoundAverageTrading = components[157];
            row.posOverTotalTrading = components[158];
            row.neuOverTotalTrading = components[159];
            row.negOverTotalTrading = components[160];
            row.totalTweetCountTrump = components[161];
            row.totalPosTweetsTrump = components[162];
            row.totalNeuTweetsTrump = components[163];
            row.totalNegTweetsTrump = components[164];
            row.totalCompoundAverageTrump = components[165];
            row.posOverTotalTrump = components[166];
            row.neuOverTotalTrump = components[167];
            row.negOverTotalTrump = components[168];
            row.stockChina = components[169];
            row.stockEurope = components[170];
            row.stockFrance = components[171];
            row.stockGerman = components[172];
            row.stockIndia = components[173];
            row.stockUk = components[174];
            row.stockUsa = components[175];
            row.eurTryExchange = components[176];
            row.eurUsdExchange = components[177];
            row.gbpUsdExchange = components[178];
            row.usdTryExchange = components[179];
            machineLearningInputRows.add(row);
        }

        return machineLearningInputRows;
    }

    public void shift() throws IOException {
        ArrayList<MachineLearningInputRow> machineLearningInputRows = readMachineLearningFile("Outputs/Organised/OrganisedForMachineLearning.txt");
        MachineLearningInputRow header = machineLearningInputRows.get(0);
        for (int i = 2; i < machineLearningInputRows.size(); i++) {
            machineLearningInputRows.get(i - 1).usdTryExchange = machineLearningInputRows.get(i).usdTryExchange;
        }

        machineLearningInputRows.remove(0); // Delete header
        machineLearningInputRows.remove(machineLearningInputRows.size() - 1); // Delete Last line since it is used

        writeInputRowsToFile("Outputs/Organised/OrganisedForMachineLearningShifted.txt", machineLearningInputRows);
    }

    private void writeInputRowsToFile(String filename, ArrayList<MachineLearningInputRow> machineLearningInputRows) throws IOException {
        String aggregatedHeaders = machineLearningInputRows.get(0).getHeaders() + "\n";
        TweetUtils.createFileWithHeaders(filename, aggregatedHeaders);
        Collections.sort(machineLearningInputRows);

        machineLearningInputRows.forEach(row -> {
            try (Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(filename, true), StandardCharsets.UTF_8))) {
                out.write(row.getRowAsString());
                out.write("\n");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
