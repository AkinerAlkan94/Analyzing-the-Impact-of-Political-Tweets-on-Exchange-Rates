import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Merger {

    public Merger() {
    }

    private static HashMap<String, String> readMoneyFile(String filename) throws IOException {
        HashMap<String, String> moneyResults = new HashMap<>();

        List<String> lines = Files.readAllLines(Paths.get(filename));
        lines.remove(0); // Remove Header
        for (String line : lines) {
            String[] components = line.split(",");
            String value = components[components.length - 2];
            String[] times = components[0].split(" ");
            String[] dayMonthYear = times[0].split("\\.");
            String createdAt = dayMonthYear[2] + "-" + dayMonthYear[1] + "-" + dayMonthYear[0] + "/" + times[1].split(":")[0];
            moneyResults.put(createdAt, value);
        }

        return moneyResults;
    }

    private static HashMap<String, OrganisedTweetResult> readTweetResultFile(String filename) throws IOException {
        HashMap<String, OrganisedTweetResult> organisedTweetResults = new HashMap<>();
        List<String> lines = Files.readAllLines(Paths.get(filename));
        lines.remove(0); // Remove Header

        for (String line : lines) {
            String[] components = line.split(TweetRetriever.SPLITERATOR);

            String yearMonthDayHour = components[0];
            String[] times = yearMonthDayHour.split(" ");
            String[] yearMonthDay = times[0].split("-");
            String createdAt = yearMonthDay[0] + "-" + yearMonthDay[1] + "-" + yearMonthDay[2] + "/" + times[1];

            OrganisedTweetResult organisedTweetResult = new OrganisedTweetResult(createdAt, components[1], components[2], components[3], components[4],
                    components[5], components[6], components[7], components[8], components[9]);
            organisedTweetResults.put(createdAt, organisedTweetResult);
        }

        return organisedTweetResults;
    }

    public void merge() throws IOException {
        ArrayList<MachineLearningInputRow> machineLearningInputRows = new ArrayList<>();
        FillTweetHashtagFeatures(machineLearningInputRows);
        FillCurrencyExchangeRateFeatures(machineLearningInputRows);
        writeInputRowsToFile("Outputs/Organised/OrganisedForMachineLearning.txt", machineLearningInputRows);
    }

    private void FillTweetHashtagFeatures(ArrayList<MachineLearningInputRow> machineLearningInputRows) throws IOException {
        HashMap<String, OrganisedTweetResult> breakingOrganised = readTweetResultFile("Organised/#breaking_Organised");
        breakingOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalBreaking = tweet.negativeOverTotal;
            inputRow.neuOverTotalBreaking = tweet.neutralOverTotal;
            inputRow.posOverTotalBreaking = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageBreaking = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsBreaking = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsBreaking = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsBreaking = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountBreaking = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> breakingnewsOrganised = readTweetResultFile("Organised/#breakingnews_Organised");
        breakingnewsOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalBreakingnews = tweet.negativeOverTotal;
            inputRow.neuOverTotalBreakingnews = tweet.neutralOverTotal;
            inputRow.posOverTotalBreakingnews = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageBreakingnews = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsBreakingnews = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsBreakingnews = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsBreakingnews = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountBreakingnews = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> currencyOrganised = readTweetResultFile("Organised/#currency_Organised");
        currencyOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalCurrency = tweet.negativeOverTotal;
            inputRow.neuOverTotalCurrency = tweet.neutralOverTotal;
            inputRow.posOverTotalCurrency = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageCurrency = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsCurrency = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsCurrency = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsCurrency = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountCurrency = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> dayOrganised = readTweetResultFile("Organised/#day_Organised");
        dayOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalDay = tweet.negativeOverTotal;
            inputRow.neuOverTotalDay = tweet.neutralOverTotal;
            inputRow.posOverTotalDay = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageDay = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsDay = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsDay = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsDay = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountDay = tweet.totalTweetCount;
        });


        HashMap<String, OrganisedTweetResult> dolarOrganised = readTweetResultFile("Organised/#dolar_Organised");
        dolarOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalDolar = tweet.negativeOverTotal;
            inputRow.neuOverTotalDolar = tweet.neutralOverTotal;
            inputRow.posOverTotalDolar = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageDolar = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsDolar = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsDolar = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsDolar = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountDolar = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> dollarOrganised = readTweetResultFile("Organised/#dollar_Organised");
        dollarOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalDollar = tweet.negativeOverTotal;
            inputRow.neuOverTotalDollar = tweet.neutralOverTotal;
            inputRow.posOverTotalDollar = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageDollar = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsDollar = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsDollar = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsDollar = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountDollar = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> donaldtrumpOrganised = readTweetResultFile("Organised/#donaldtrump_Organised");
        donaldtrumpOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalDonaldtrump = tweet.negativeOverTotal;
            inputRow.neuOverTotalDonaldtrump = tweet.neutralOverTotal;
            inputRow.posOverTotalDonaldtrump = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageDonaldtrump = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsDonaldtrump = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsDonaldtrump = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsDonaldtrump = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountDonaldtrump = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> economyOrganised = readTweetResultFile("Organised/#economy_Organised");
        economyOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalEconomy = tweet.negativeOverTotal;
            inputRow.neuOverTotalEconomy = tweet.neutralOverTotal;
            inputRow.posOverTotalEconomy = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageEconomy = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsEconomy = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsEconomy = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsEconomy = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountEconomy = tweet.totalTweetCount;
        });


        HashMap<String, OrganisedTweetResult> euroOrganised = readTweetResultFile("Organised/#euro_Organised");
        euroOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalEuro = tweet.negativeOverTotal;
            inputRow.neuOverTotalEuro = tweet.neutralOverTotal;
            inputRow.posOverTotalEuro = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageEuro = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsEuro = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsEuro = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsEuro = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountEuro = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> exchangeOrganised = readTweetResultFile("Organised/#exchange_Organised");
        exchangeOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalExchange = tweet.negativeOverTotal;
            inputRow.neuOverTotalExchange = tweet.neutralOverTotal;
            inputRow.posOverTotalExchange = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageExchange = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsExchange = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsExchange = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsExchange = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountExchange = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> forexOrganised = readTweetResultFile("Organised/#forex_Organised");
        forexOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalForex = tweet.negativeOverTotal;
            inputRow.neuOverTotalForex = tweet.neutralOverTotal;
            inputRow.posOverTotalForex = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageForex = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsForex = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsForex = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsForex = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountForex = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> investingOrganised = readTweetResultFile("Organised/#investing_Organised");
        investingOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalInvesting = tweet.negativeOverTotal;
            inputRow.neuOverTotalInvesting = tweet.neutralOverTotal;
            inputRow.posOverTotalInvesting = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageInvesting = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsInvesting = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsInvesting = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsInvesting = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountInvesting = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> marketOrganised = readTweetResultFile("Organised/#market_Organised");
        marketOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalMarket = tweet.negativeOverTotal;
            inputRow.neuOverTotalMarket = tweet.neutralOverTotal;
            inputRow.posOverTotalMarket = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageMarket = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsMarket = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsMarket = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsMarket = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountMarket = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> moneyOrganised = readTweetResultFile("Organised/#money_Organised");
        moneyOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalMoney = tweet.negativeOverTotal;
            inputRow.neuOverTotalMoney = tweet.neutralOverTotal;
            inputRow.posOverTotalMoney = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageMoney = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsMoney = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsMoney = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsMoney = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountMoney = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> obamaOrganised = readTweetResultFile("Organised/#obama_Organised");
        obamaOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalObama = tweet.negativeOverTotal;
            inputRow.neuOverTotalObama = tweet.neutralOverTotal;
            inputRow.posOverTotalObama = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageObama = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsObama = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsObama = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsObama = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountObama = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> stockOrganised = readTweetResultFile("Organised/#stock_Organised");
        stockOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalStock = tweet.negativeOverTotal;
            inputRow.neuOverTotalStock = tweet.neutralOverTotal;
            inputRow.posOverTotalStock = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageStock = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsStock = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsStock = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsStock = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountStock = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> stockmarketOrganised = readTweetResultFile("Organised/#stockmarket_Organised");
        stockmarketOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalStockmarket = tweet.negativeOverTotal;
            inputRow.neuOverTotalStockmarket = tweet.neutralOverTotal;
            inputRow.posOverTotalStockmarket = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageStockmarket = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsStockmarket = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsStockmarket = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsStockmarket = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountStockmarket = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> stocksOrganised = readTweetResultFile("Organised/#stocks_Organised");
        stocksOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalStocks = tweet.negativeOverTotal;
            inputRow.neuOverTotalStocks = tweet.neutralOverTotal;
            inputRow.posOverTotalStocks = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageStocks = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsStocks = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsStocks = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsStocks = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountStocks = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> todayOrganised = readTweetResultFile("Organised/#today_Organised");
        todayOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalToday = tweet.negativeOverTotal;
            inputRow.neuOverTotalToday = tweet.neutralOverTotal;
            inputRow.posOverTotalToday = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageToday = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsToday = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsToday = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsToday = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountToday = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> tradingOrganised = readTweetResultFile("Organised/#trading_Organised");
        tradingOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalTrading = tweet.negativeOverTotal;
            inputRow.neuOverTotalTrading = tweet.neutralOverTotal;
            inputRow.posOverTotalTrading = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageTrading = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsTrading = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsTrading = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsTrading = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountTrading = tweet.totalTweetCount;
        });

        HashMap<String, OrganisedTweetResult> trumpOrganised = readTweetResultFile("Organised/#trump_Organised");
        trumpOrganised.values().forEach(tweet -> {
            initializeRowIfNotFound(machineLearningInputRows, tweet.createdAt);
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(tweet.createdAt)).findFirst().get();
            inputRow.negOverTotalTrump = tweet.negativeOverTotal;
            inputRow.neuOverTotalTrump = tweet.neutralOverTotal;
            inputRow.posOverTotalTrump = tweet.positiveOverTotal;
            inputRow.totalCompoundAverageTrump = tweet.totalCompoundAverage;
            inputRow.totalNegTweetsTrump = tweet.totalNegTweetCount;
            inputRow.totalNeuTweetsTrump = tweet.totalNeuTweetCount;
            inputRow.totalPosTweetsTrump = tweet.totalPositiveTweetCount;
            inputRow.totalTweetCountTrump = tweet.totalTweetCount;
        });

        /* Stock Market Features */
        Map<String, String> stockChina = readMoneyFile("Organised/stockChina.csv");
        stockChina.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockChina = value;
        });

        Map<String, String> stockEurope = readMoneyFile("Organised/stockEurope.csv");
        stockEurope.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockEurope = value;
        });

        Map<String, String> stockFrance = readMoneyFile("Organised/stockFrance.csv");
        stockFrance.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockFrance = value;
        });

        Map<String, String> stockGerman = readMoneyFile("Organised/stockGerman.csv");
        stockGerman.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockGerman = value;
        });

        Map<String, String> stockIndia = readMoneyFile("Organised/stockIndia.csv");
        stockIndia.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockIndia = value;
        });

        Map<String, String> stockUk = readMoneyFile("Organised/stockUk.csv");
        stockUk.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockUk = value;
        });

        Map<String, String> stockUsa = readMoneyFile("Organised/stockUsa.csv");
        stockUsa.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.stockUsa = value;
        });
    }

    private void initializeRowIfNotFound(ArrayList<MachineLearningInputRow> machineLearningInputRows, String createdAt) {
        if (!machineLearningInputRows.stream().anyMatch(row -> row.createdAt.equals(createdAt))) {
            machineLearningInputRows.add(new MachineLearningInputRow(createdAt));
        }
    }

    private void FillCurrencyExchangeRateFeatures(ArrayList<MachineLearningInputRow> machineLearningInputRows) throws IOException {
        Map<String, String> eurTry = readMoneyFile("Organised/eurTry.csv");
        eurTry.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.eurTryExchange = value;
        });

        Map<String, String> eurUsd = readMoneyFile("Organised/eurUsd.csv");
        eurUsd.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.eurUsdExchange = value;
        });

        Map<String, String> gbpUsd = readMoneyFile("Organised/gbpUsd.csv");
        gbpUsd.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.gbpUsdExchange = value;
        });

        Map<String, String> usdTry = readMoneyFile("Organised/usdTry.csv"); // Target Feature
        usdTry.forEach((createdAt, value) -> {
            MachineLearningInputRow inputRow = machineLearningInputRows.stream().filter(row -> row.createdAt.equals(createdAt)).findFirst().orElse(new MachineLearningInputRow(""));
            inputRow.usdTryExchange = value;
        });
    }

    public void writeInputRowsToFile(String filename, ArrayList<MachineLearningInputRow> machineLearningInputRows) throws IOException {
        String aggregatedHeaders = machineLearningInputRows.get(0).getHeaders() + "\n";
        TweetUtils.createFileWithHeaders(filename, aggregatedHeaders);
        Collections.sort(machineLearningInputRows);

        machineLearningInputRows.forEach(row -> {
            try (Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(filename, true), StandardCharsets.UTF_8))) {
                out.write(row.getRowAsString());
                out.write("\n");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}