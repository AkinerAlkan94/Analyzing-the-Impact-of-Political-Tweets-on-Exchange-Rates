import org.apache.log4j.*;

public class Bootstrap {
    private static Logger log = LogManager.getLogger(Bootstrap.class);

    public static void main(String[] args) {
        try {
            if (args[0] != null && args[0].toLowerCase().equals("-mergeall")){
                new Merger().merge();
                return;
            }

            if (args[0] != null && args[0].toLowerCase().equals("-shiftline")){
                new Shifter().shift();
                return;
            }

            boolean isSkipFetch = false;

            Logger rootLogger = Logger.getRootLogger();
            rootLogger.setLevel(Level.INFO);

            PatternLayout layout = new PatternLayout("%d{ISO8601} [%t] %-5p %c %x - %m%n");
            RollingFileAppender fileAppender = new RollingFileAppender(layout, "demoApplication.log");
            rootLogger.addAppender(fileAppender);

            String[] tags = null;
            for (int i = 0; i < args.length; i++) {
                if (args[i].toLowerCase().equals("-tags")) {
                    tags = args[i + 1].split(",");
                }
                if (args[i].toLowerCase().equals("-skipfetch")) {
                    isSkipFetch = true;
                }
            }

            BasicConfigurator.configure();
            if (tags == null) {
                log.error("HashTags are not given.\n Example Usage: jarname -tags hashtag1,hashtag2..");
                return;
            }


            if (!isSkipFetch) TweetRetriever.fetchSearchTerms(tags);

            for (String tag : tags) {
                new Organiser(Strategy.KEEP_AS_IT_IS, Strategy.DROP).organiseResult(tag);
            }

        } catch (Exception e) {
            log.error("Exception Occurred", e);
            e.printStackTrace();
        }
    }
}
