import com.vader.sentiment.analyzer.SentimentAnalyzer;

import java.io.IOException;
import java.util.Map;
import java.util.StringJoiner;

public class Tweet {
    private Long id;
    private String createdAt;
    private String text;
    private String tag;

    private float negative;
    private float neutral;
    private float positive;
    private float compound;
    private PolaritySentiment sentiment;

    public Tweet(Long id, String createdAt, String tag, String text) throws IOException {
        this.id = id;
        this.createdAt = createdAt;
        this.tag = tag;
        this.text = TweetUtils.cleanText(text);

        SentimentAnalyzer sentimentAnalyzer = new SentimentAnalyzer(this.text);
        sentimentAnalyzer.analyze();
        Map<String, Float> polarity = sentimentAnalyzer.getPolarity();
        this.negative = polarity.get("negative");
        this.neutral = polarity.get("neutral");
        this.positive = polarity.get("positive");
        this.compound = polarity.get("compound");
        this.sentiment = TweetUtils.getPolaritySentiment(compound);
    }

    public long getId() { return id; }
    public String getCreatedAt() { return createdAt; }
    public float getCompound() { return compound; }
    public float getNegative() { return negative; }
    public float getPositive() { return positive; }
    public float getNeutral() { return neutral; }
    public String getTag() { return tag; }
    public PolaritySentiment getSentiment() { return sentiment; }

    @Override
    public String toString() {
        StringJoiner stringJoiner = new StringJoiner(TweetRetriever.SPLITERATOR);
        stringJoiner.add(id.toString());
        stringJoiner.add(createdAt);
        stringJoiner.add(tag);
        stringJoiner.add(text);
        stringJoiner.add(String.valueOf(negative));
        stringJoiner.add(String.valueOf(neutral));
        stringJoiner.add(String.valueOf(positive));
        stringJoiner.add(String.valueOf(compound));
        stringJoiner.add(sentiment.toString());
        return stringJoiner.toString();
    }
}
