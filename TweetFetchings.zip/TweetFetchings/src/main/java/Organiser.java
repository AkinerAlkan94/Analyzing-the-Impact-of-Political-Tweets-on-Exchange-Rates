import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Organiser {
    private static Logger log = LogManager.getLogger(Organiser.class);

    Strategy publicHolidaysStrategy;
    Strategy weekendsStrategy;

    public Organiser(Strategy publicHolidaysStrategy, Strategy weekendsStrategy) {
        this.publicHolidaysStrategy = publicHolidaysStrategy;
        this.weekendsStrategy = weekendsStrategy;
    }

    public void organiseResult(String searchTerm) throws Exception {
        List<Tweet> tweetsForTag = TweetUtils.readTweetsFromFiles(TweetUtils.listAllFilesForSearchTerm(searchTerm));

        if (weekendsStrategy.equals(Strategy.DROP)) {
            tweetsForTag = TweetUtils.dropWeekends(tweetsForTag);
        }

        tweetsForTag = TweetUtils.dropInactiveHours(tweetsForTag);

        Map<String, List<Tweet>> organisedTweets = organiseHourly(tweetsForTag);

        print("Outputs/Organised/" + searchTerm + "_Organised", organisedTweets);
    }

    private Map<String, List<Tweet>> organiseHourly(List<Tweet> tweets) {
        Map<String, List<Tweet>> organisedTweets = new HashMap<>();
        for (Tweet tweet : tweets) {
            String createdAt = TweetUtils.truncateCreatedAtTimeForHourly(tweet.getCreatedAt());

            if (!organisedTweets.containsKey(createdAt)) {
                organisedTweets.put(createdAt, new ArrayList<>());
            }

            organisedTweets.get(createdAt).add(tweet);
        }

        return organisedTweets;
    }

    private void print(String filename, Map<String, List<Tweet>> tweets) throws IOException {
        String headers = "CREATED_AT    TAG    TOTAL_TWEET_COUNT    TOTAL_POS_TWEETS    TOTAL_NEU_TWEETS    TOTAL_NEG_TWEETS    TOTAL_COMPOUND_AVERAGE    POS/TOTAL    NEU/TOTAL    NEG/TOTAL\n";
        TweetUtils.createFileWithHeaders(filename, headers);

        TreeMap<String, List<Tweet>> xx = new TreeMap<>(tweets);

        for (Map.Entry<String, List<Tweet>> entry : xx.entrySet()) {
            String createdAt = entry.getKey();
            List<Tweet> tweetList = entry.getValue();
            double totalCompound = tweetList.stream().mapToDouble(t -> (double) t.getCompound()).sum();
            int totalTweetCount = tweetList.size();
            long positiveTweetCount = tweetList.stream().filter(t -> t.getSentiment().equals(PolaritySentiment.POS)).count();
            long neutralTweetCount = tweetList.stream().filter(t -> t.getSentiment().equals(PolaritySentiment.NEU)).count();
            long negativeTweetCount = tweetList.stream().filter(t -> t.getSentiment().equals(PolaritySentiment.NEG)).count();
            String tag = tweetList.get(0).getTag();

            StringJoiner stringJoiner = new StringJoiner(TweetRetriever.SPLITERATOR);
            stringJoiner.add(createdAt);
            stringJoiner.add(tag);
            stringJoiner.add(String.valueOf(totalTweetCount));

            stringJoiner.add(String.valueOf(positiveTweetCount));
            stringJoiner.add(String.valueOf(neutralTweetCount));
            stringJoiner.add(String.valueOf(negativeTweetCount));

            stringJoiner.add(String.valueOf(totalCompound / totalTweetCount));

            stringJoiner.add(String.valueOf((float) positiveTweetCount / totalTweetCount));
            stringJoiner.add(String.valueOf((float) neutralTweetCount / totalTweetCount));
            stringJoiner.add(String.valueOf((float) negativeTweetCount / totalTweetCount));

            try (Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(filename, true), StandardCharsets.UTF_8))) {
                out.write(stringJoiner.toString());
                out.write("\n");
            }
        }
    }


}