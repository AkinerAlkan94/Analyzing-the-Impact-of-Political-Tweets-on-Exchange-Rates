public enum Strategy
{
    KEEP_AS_IT_IS,DROP,AGGREGATE
}
