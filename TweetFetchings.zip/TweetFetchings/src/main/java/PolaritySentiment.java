public enum PolaritySentiment
{
    NEG,NEU,POS
}
