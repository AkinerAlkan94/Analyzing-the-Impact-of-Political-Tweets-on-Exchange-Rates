import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TweetUtils {
    private static final String CONSUMER_KEY = "";
    private static final String CONSUMER_SECRET = "";
    private static final String ACCESS_TOKEN = "";
    private static final String ACCESS_TOKEN_SECRET = "";
    public static DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static Logger log = LogManager.getLogger(TweetUtils.class);

    public static Twitter createTwitter() {
        return new TwitterFactory(new ConfigurationBuilder().setDebugEnabled(true).setTweetModeExtended(true)
                .setOAuthConsumerKey(CONSUMER_KEY).setOAuthConsumerSecret(CONSUMER_SECRET)
                .setOAuthAccessToken(ACCESS_TOKEN).setOAuthAccessTokenSecret(ACCESS_TOKEN_SECRET).build())
                .getInstance();
    }


    public static String cleanText(String text) {
        return text.replaceAll("[\\S]+://[\\S]+", " ")
                .replace("\n", " ").replace("\r", " ")
                .replace("\t", " ").replace("\r\n", " ");
    }

    public static String getTweetText(Status tweetStatus) {
        String text = tweetStatus.getText();

        if (tweetStatus.getRetweetedStatus() != null) {
            text = tweetStatus.getRetweetedStatus().getText();
        }
        return text;
    }

    public static PolaritySentiment getPolaritySentiment(float compound) {
        PolaritySentiment sentiment = PolaritySentiment.NEU;
        if (compound < -0.05) {
            sentiment = PolaritySentiment.NEG;
        } else if (compound > 0.05) {
            sentiment = PolaritySentiment.POS;
        }
        return sentiment;
    }

    public static void WriteTweetToFile(Tweet tweet, String filename) throws Exception {
        try (Writer out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(filename, true), StandardCharsets.UTF_8))) {
            out.write(tweet.toString());
            out.write("\n");
        }
    }

    public static void createFile(String filename) throws IllegalStateException {
        File targetFile = new File(filename);
        if (targetFile.exists()) {
            boolean _result = targetFile.delete();
        }

        File parent = targetFile.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) {
            throw new IllegalStateException("Couldn't create dir: " + parent);
        }
    }

    public static void createFileWithHeaders(String filename, String headers) throws IOException {
        TweetUtils.createFile(filename);
        try (Writer out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(filename, true), StandardCharsets.UTF_8))) {
            out.write(headers);
        }
    }

    public static String truncateCreatedAtTimeForHourly(String createdAt) {
        // "yyyy-MM-dd HH:mm:ss" returns as "yyyy-MM-dd HH"
        String[] date = createdAt.split(" ");
        String[] hour = date[1].split(":");
        createdAt = date[0] + " " + hour[0];
        return createdAt;
    }

    public static List<String> listAllFilesForSearchTerm(String searchTerm) throws Exception {
        try (Stream<Path> walk = Files.walk(Paths.get("Outputs"))) {
            return walk.map(Path::toString).filter(f -> {
                return f.startsWith("Outputs\\" + searchTerm);
            }).collect(Collectors.toList());
        }
    }

    public static List<Tweet> readTweetsFromFiles(List<String> filenames) throws IOException {
        Splitter splitter = Splitter.on(TweetRetriever.SPLITERATOR);
        ArrayList<Tweet> tweets = new ArrayList<>();
        for (String filename : filenames) {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            lines.remove(0); // Remove Header
            for (String line : lines) {
                String[] components = Iterables.toArray(splitter.split(line), String.class);
                if (components.length != 9) {
                    log.error("Error occurred. Skipping Problematic Tweet.");
                    continue;
                }

                Tweet tweet = new Tweet(Long.parseLong(components[0]), components[1], components[2], components[3]);
                tweets.add(tweet);
            }
        }

        return distinct(tweets);
    }

    public static List<Tweet> distinct(ArrayList<Tweet> tweets) {
        Map<Long, Tweet> distincts = new HashMap<>();
        tweets.forEach(t -> {
            if (!distincts.containsKey(t.getId())) {
                distincts.put(t.getId(), t);
            }
        });

        return new ArrayList<>(distincts.values());
    }

    public static List<Tweet> dropWeekends(List<Tweet> tweets) {
        return tweets.stream().filter(tweet -> {
            try {
                Calendar calendar = Calendar.getInstance();
                Date date = TweetUtils.DATE_FORMAT.parse(tweet.getCreatedAt());
                calendar.setTime(date);
                return !((calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) || (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY));
            } catch (ParseException e) {
                log.error("Dropping Tweet since it's date format is corrupted.");
            }

            return false;
        }).collect(Collectors.toList());
    }

    public static List<Tweet> dropInactiveHours(List<Tweet> tweets) {
        return tweets.stream().filter(tweet -> {
            int hour = Integer.parseInt(tweet.getCreatedAt().split(" ")[1].split(":")[0]);
            return ((hour >= 8) && (hour <= 18));
        }).collect(Collectors.toList());
    }
}
